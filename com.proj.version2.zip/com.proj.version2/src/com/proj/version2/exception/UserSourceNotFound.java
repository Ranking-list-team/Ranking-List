package com.proj.version2.exception;

public class UserSourceNotFound extends Exception{

}

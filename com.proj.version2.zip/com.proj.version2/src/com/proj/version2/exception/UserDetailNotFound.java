package com.proj.version2.exception;

public class UserDetailNotFound {

}

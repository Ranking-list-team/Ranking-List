package com.proj.version2.exception;

public class PlatformScoreNotFound extends Exception{

}
